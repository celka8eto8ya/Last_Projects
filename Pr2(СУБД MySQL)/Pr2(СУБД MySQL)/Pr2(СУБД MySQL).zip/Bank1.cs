﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr2_СУБД_MySQL_
{
    public static class Bank1
    {
        public static string Disk = ""; // диск на котором будут храниться дополнительные файлы
        public static string Put = ""; // путь сохранения файла с информацией по пользователям
        public static int Isp = 0; // для занесения данных в таблицу
        public static string INF = ""; // информация о учетной записи (строка файла)
        public static int TIP = -1; // для определения типа выходных данных
        public static string UchName = ""; // имя ученой записи
        public static string CONNSTR = ""; // данные для обращения к БД

    }
}
