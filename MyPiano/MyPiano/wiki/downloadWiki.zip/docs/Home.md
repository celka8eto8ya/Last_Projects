## NAudio Overview
**IMPORTANT** The latest NAudio source code can now be found on [GitHub](http://github.com/naudio/NAudio). For now, CodePlex remains the place to access documentation, discussions and downloads.

NAudio is an open source .NET audio and MIDI library, containing dozens of useful audio related classes intended to speed development of audio related utilities in .NET. It has been in development since 2002 and has grown to include a wide variety of features. While some parts of the library are relatively new and incomplete, the more mature features have undergone extensive testing and can be quickly used to add audio capabilities to an existing .NET application. NAudio can be quickly added to your .NET application [using NuGet](https://nuget.org/packages/NAudio).

_NAudio demo project showing an MP3 file playing:_
![](Home_naudiodemo.png)

_NAudio WPF Project showing waveform visualisation and spectrum analyser:_
![](Home_NAudioWPF.png)
## Latest News
For the latest news and more documentation on NAudio, visit [Mark Heath's blog](http://mark-dot-net.blogspot.com/search/label/NAudio).

* **27 Dec 2016** NAudio 1.8 released. Read the [release notes](http://www.markheath.net/post/announcing-naudio-1.8)
* **24 Nov 2014** NAudio 1.7.2 Released with lots of minor enhancements and bugfixes
* **4 Nov 2013** [Programming Audio with NAudio](http://pluralsight.com/training/Courses/TableOfContents/audio-programming-naudio) training course released on Pluralsight
* **29 Oct 2013** NAudio 1.7 Released. Read the [release notes](http://mark-dot-net.blogspot.co.uk/2013/10/naudio-17-release-notes.html)
* **26 Oct 2012** NAudio 1.6 Released. Read the [release notes](http://mark-dot-net.blogspot.co.uk/2012/10/naudio-16-release-notes-10th.html)
* **9 Sep 2012** ASIO Recording Support added
* **19 Dec 2011** NAudio 1.5 Released. Read the [release notes](http://mark-dot-net.blogspot.com/2011/12/naudio-15-released.html)
* **20 Apr 2011** NAudio 1.4 Released. Read the [release notes](http://mark-dot-net.blogspot.com/2011/04/naudio-14-release-notes.html)
* **15 Apr 2011** NAudio demo now shows how to select output devices (for WaveOut, DirectSound, WASAPI and ASIO), and can play 8 bit, 16 bit, 24 bit, and 32 bit float WAV files. Fixed a longstanding ASIO issue.
* **7 Nov 2010** Major improvements to Mp3FileReader
* **10 Oct 2009** Version 1.3 Released. Read the [release notes](http://mark-dot-net.blogspot.com/2009/10/naudio-13-release-notes.html)
* **20 Sep 2009** We are getting close to feature complete for 1.3. Last chance to get in any feedback on the API
* **26 Aug 2009** WPF Waveform drawing demo project including FFT added
* **28 Feb 2009** Lots of new stuff is being added and planned, so do check out the Source Code tab to have a sneak peak at what's coming in 1.3
* **26 June 2008** Version 1.2 Released. Read the [release notes](http://mark-dot-net.blogspot.com/2008/06/naudio-12-release-notes.html)
## NAudio Features
* Play back audio using a variety of APIs
	* WaveOut
	* DirectSound
	* ASIO
	* WASAPI (Windows Vista and above)
* Decompress audio from different Wave Formats
	* MP3 decode using ACM or DMO codec
	* AIFF
	* G.711 mu-law and a-law
	* ADPCM
	* G.722
	* Speex (using NSpeex)
	* SF2 files
	* Decode using any ACM codec installed on your computer
* Record audio using WaveIn, WASAPI or ASIO
* Read and Write standard .WAV files
* Mix and manipulate audio streams using a 32 bit floating mixing engine
* Extensive support for reading and writing MIDI files
* Full MIDI event model
* Basic support for Windows Mixer APIs
* A collection of useful Windows Forms Controls
* Some basic audio effects, including a compressor
## Projects Using NAudio
NAudio currently is used to support a number of audio related utilities, some of which may be moved to be hosted on CodePlex in the future. If you have used NAudio for a project, please get in touch so we can post it here.
* [Skype Voice Changer](http://skypevoicechanger.net) - Modify your voice with audio effects while talking on Skype
* [.NET Voice Recorder](http://voicerecorder.codeplex.com) - Record your voice, save to MP3, and visualise the waveform using WPF. Now includes autotune
* [Pree](http://qedcode.com/pree) - Record spoken word without the need for editing. 
* [MIDI File Mapper](http://www.codeplex.com/midifilemapper) - Utility for mapping MIDI drum files for use on other samplers
* [MIDI File Splitter](http://www.codeplex.com/midifilesplitter) - Split MIDI files up at their markers
* [SharpMod](http://sharpmod.codeplex.com/) - managed port of MikMod, can play mod files in both WinForms and Silverlight
* [NVorbis](http://nvorbis.codeplex.com/) - Fully managed Vorbis decoder, with support for NAudio
* [Practice#](http://code.google.com/p/practicesharp/) - Windows tool for practicing playing an instrument with playback music. **Includes FLAC playback support and an equaliser for NAudio.**
* [WPF Sound Visualization Library](http://wpfsvl.codeplex.com) - beautiful waveform and spectrum analyzer code written for WPF, comes with NAudio sample
* [Q2Cue](http://q2cue.codeplex.com) - application for running audio cues in a theatrical or other performance related settings
* [TuneBlade](http://www.tuneblade.com/) - Stream Windows' audio to AirPlay receivers
* [Teachey Teach](http://www.teacheyteach.com/) - utility to help English language conversation teachers generate feedback for students
* [Sound Mill](http://breakthrusoftware.com/html/products/soundmgr/index.html) -  an audio player, list organizer and automation manager
* [Bravura Studio](http://cybermental.com/bravura-studio/) - a modular, extensible application and platform for creating and experimenting with music and audio.
* [musiX](http://raphaelgodart.tumblr.com/)
* [SIPSorcery](http://sipsorcery.codeplex.com) - .NET softphone framework
* [Squiggle](http://squiggle.codeplex.com/) - A free open source LAN Messenger
* [Helix 3D toolkit](http://helixtoolkit.codeplex.com/) - Multi-format audio player
* [airphone-tv](http://code.google.com/p/airphone-tv/) - A revival of axStream to implement control through the iPhone
* [JamNet](http://jamnet.codeplex.com/) - a Silverlight drum sample player
* [Jingle Jim](http://www.jinglejim.de/Startseite.aspx) - Jingle Software (German language)
* [All My Music](http://www.winisoft.ch)
* [iSpy](http://www.ispyconnect.com/) - Open Source Camera Security Software
* [RadioTuna](http://radiotuna.com/OnlineRadioPlayer/Intro) - Online internet radio player
* [Fire Talk New](www.firetalknew.com) - chat program
* [AVR Audio Guard](http://www.marcsapps.co.uk/) - utility to fix a HDMI related issue
* [Locutor da Hora](http://locutordahora.unijui.edu.br/o-software/) - Educational app simulating a radio studio
* [uAudio](https://www.assetstore.unity3d.com/en/#!/content/42677) - Audio player component for Unity3D
* [Radio Pro](https://www.assetstore.unity3d.com/en/#!/content/32034) - Unity 3D Radio Asset
* [NAudio DTMF](https://github.com/art-drobanov/NAudio.DTMF) - NAudio DTMF example code
## More Info

For more information, please visit the [NAudio Documentation Wiki](http://naudio.codeplex.com/documentation)

## Donate
NAudio is a free open source project that is developed in personal time. You can show your appreciation for NAudio and support future development by donating.
![Donate](Home_btn_donateCC_LG.gif|https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TE4B48U2PPEL6)