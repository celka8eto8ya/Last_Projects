## NAudio Roadmap
NAudio features are being added on an as-needed basis. Here's some things that may be on the horizon...

* A piano roll control
* Possibly some WPF contols
* Investigate wrapping some lower latency Wave streaming APIs - e.g. WDM, ASIO, or something like PortAudio
